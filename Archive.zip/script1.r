source("script.r");

load("dictionary.rdata")
load("articles.rdata")
spm.1<- prepareSparseDocumentMatrix(articles.list[[1]], word.dictionary)

save(spm.1, "spm1.rdata");