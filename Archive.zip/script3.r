source("script.r");
load("dictionary.rdata")
load("articles.rdata")
spm.3<- prepareSparseDocumentMatrix(articles.list[[1]], word.dictionary)

save(spm.3, "spm1.rdata");