source("script.r");
load("dictionary.rdata")
load("articles.rdata")
spm.2<- prepareSparseDocumentMatrix(articles.list[[1]], word.dictionary)

save(spm.2, "spm1.rdata");